package com.schallenge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101116)
private val Panel = Color(0xFF1B1D26)
private val Gold = Color(0xFFF2C35B)
private val Muted = Color(0xFFAAADBA)
private val White = Color(0xFFF8F7F2)

data class Question(val category: String, val text: String, val choices: List<String>, val answer: Int, val note: String)

private val questions = listOf(
    Question("كرة القدم", "أي منتخب فاز بكأس العالم 2022؟", listOf("فرنسا", "الأرجنتين", "البرازيل", "ألمانيا"), 1, "الأرجنتين توجت باللقب بعد الفوز على فرنسا بركلات الترجيح."),
    Question("كرة القدم", "كم لاعباً يبدأ به الفريق المباراة داخل الملعب؟", listOf("10", "11", "12", "9"), 1, "يتكون الفريق من 11 لاعباً، بمن فيهم حارس المرمى."),
    Question("كرة القدم", "ما النادي المعروف بلقب النادي الملكي؟", listOf("برشلونة", "ليفربول", "ريال مدريد", "ميلان"), 2, "ريال مدريد يُعرف بلقب النادي الملكي."),
    Question("التاريخ", "في أي عام انتهت الحرب العالمية الثانية؟", listOf("1943", "1944", "1945", "1946"), 2, "انتهت الحرب العالمية الثانية عام 1945."),
    Question("التاريخ", "ما الحضارة التي بنت الأهرامات في الجيزة؟", listOf("الرومانية", "المصرية القديمة", "الإغريقية", "الفارسية"), 1, "بُنيت أهرامات الجيزة في مصر القديمة."),
    Question("جغرافيا", "ما أكبر محيط على كوكب الأرض؟", listOf("الأطلسي", "الهندي", "المتجمد الشمالي", "الهادئ"), 3, "المحيط الهادئ هو الأكبر مساحةً."),
    Question("معلومات عامة", "ما الغاز الذي تمتصه النباتات من الهواء؟", listOf("الأكسجين", "النيتروجين", "ثاني أكسيد الكربون", "الهيدروجين"), 2, "تمتص النباتات ثاني أكسيد الكربون خلال عملية البناء الضوئي."),
    Question("علوم", "ما الكوكب المعروف بالكوكب الأحمر؟", listOf("الزهرة", "المريخ", "عطارد", "زحل"), 1, "يُعرف المريخ بلونه الأحمر بسبب أكاسيد الحديد على سطحه.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SChallengeApp() }
    }
}

@Composable
fun SChallengeApp() {
    var screen by remember { mutableStateOf("home") }
    var selectedCategory by remember { mutableStateOf("الكل") }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var answered by remember { mutableStateOf(false) }
    var coins by remember { mutableIntStateOf(0) }

    val categories = listOf("الكل", "كرة القدم", "التاريخ", "جغرافيا", "معلومات عامة", "علوم")
    val roundQuestions = if (selectedCategory == "الكل") questions else questions.filter { it.category == selectedCategory }
    val current = roundQuestions.getOrNull(index)

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Gold, onPrimary = Ink,
        onBackground = White, onSurface = White, secondary = Gold
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            when (screen) {
                "quiz" -> {
                    if (current == null) {
                        ResultScreen(score, roundQuestions.size, onHome = { screen = "home" }, onAgain = {
                            index = 0; score = 0; selected = -1; answered = false; screen = "quiz"
                        })
                    } else {
                        QuizScreen(
                            question = current, number = index + 1, total = roundQuestions.size,
                            selected = selected, answered = answered,
                            onSelect = { if (!answered) selected = it },
                            onConfirm = {
                                if (!answered && selected >= 0) {
                                    answered = true
                                    if (selected == current.answer) { score++; coins += 10 }
                                }
                            },
                            onNext = {
                                index++; selected = -1; answered = false
                                if (index >= roundQuestions.size) screen = "result"
                            },
                            onExit = { screen = "home"; index = 0; score = 0; selected = -1; answered = false }
                        )
                    }
                }
                "result" -> ResultScreen(score, roundQuestions.size, onHome = { screen = "home" }, onAgain = {
                    index = 0; score = 0; selected = -1; answered = false; screen = "quiz"
                })
                else -> HomeScreen(
                    categories = categories, selectedCategory = selectedCategory,
                    coins = coins, onCategory = { selectedCategory = it },
                    onStart = { index = 0; score = 0; selected = -1; answered = false; screen = "quiz" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(categories: List<String>, selectedCategory: String, coins: Int,
               onCategory: (String) -> Unit, onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("S", color = Gold, fontSize = 42.sp, fontWeight = FontWeight.Black)
                Text("CHALLENGE", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("✦", color = Gold, fontSize = 18.sp)
                    Spacer(Modifier.width(7.dp))
                    Text("$coins", color = White, fontWeight = FontWeight.Bold)
                    Text("  S Coins", color = Muted, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("أهلاً بك في عالم التحدي", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("اختبر معلوماتك، اجمع النقاط، ونافس نفسك!", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 7.dp))
        Spacer(Modifier.height(22.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("تحدي اليوم", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("هل أنت مستعد لإثبات معرفتك؟", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("أسئلة متنوعة • نقاط لكل إجابة صحيحة", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(18.dp))
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(14.dp)) {
                    Text("ابدأ التحدي  →", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
        Spacer(Modifier.height(26.dp))
        Text("اختر المجال", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("يمكنك اللعب في مجال محدد أو اختيار الكل", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 14.dp))
        categories.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                row.forEach { category ->
                    val active = selectedCategory == category
                    Card(
                        modifier = Modifier.weight(1f).clickable { onCategory(category) },
                        colors = CardDefaults.cardColors(containerColor = if (active) Gold.copy(alpha = .18f) else Panel),
                        border = if (active) androidx.compose.foundation.BorderStroke(1.dp, Gold) else null,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(15.dp)) {
                            Text(categoryEmoji(category), fontSize = 22.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(category, color = if (active) Gold else White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("نسخة تجريبية أولى • المزيد من التحديات قريباً", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

fun categoryEmoji(category: String) = when(category) {
    "كرة القدم" -> "⚽"
    "التاريخ" -> "🏛️"
    "جغرافيا" -> "🌍"
    "معلومات عامة" -> "💡"
    "علوم" -> "🔬"
    else -> "🎯"
}

@Composable
fun QuizScreen(question: Question, number: Int, total: Int, selected: Int, answered: Boolean,
               onSelect: (Int) -> Unit, onConfirm: () -> Unit, onNext: () -> Unit, onExit: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text("← خروج", color = Muted) }
            Text("السؤال $number من $total", color = Gold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        LinearProgressIndicator(progress = { number.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(7.dp),
            color = Gold, trackColor = Panel)
        Spacer(Modifier.height(26.dp))
        Text(question.category, color = Gold, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(question.text, color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
        Spacer(Modifier.height(26.dp))
        question.choices.forEachIndexed { i, choice ->
            val isCorrect = i == question.answer
            val bg = when {
                answered && isCorrect -> Color(0xFF174B37)
                answered && selected == i && !isCorrect -> Color(0xFF572B31)
                selected == i -> Gold.copy(alpha = .18f)
                else -> Panel
            }
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onSelect(i) },
                colors = CardDefaults.cardColors(containerColor = bg),
                border = if (selected == i || (answered && isCorrect)) androidx.compose.foundation.BorderStroke(1.dp, if (answered && isCorrect) Color(0xFF50D69A) else Gold) else null,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(listOf("A", "B", "C", "D")[i], color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(14.dp))
                    Text(choice, color = White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    if (answered && isCorrect) Text("✓", color = Color(0xFF50D69A), fontSize = 20.sp)
                }
            }
        }
        if (answered) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Text(question.note, color = Muted, modifier = Modifier.padding(15.dp), fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = if (answered) onNext else onConfirm, enabled = answered || selected >= 0,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, disabledContainerColor = Panel),
            shape = RoundedCornerShape(14.dp)) {
            Text(if (answered) if (number == total) "عرض النتيجة" else "السؤال التالي" else "تأكيد الإجابة",
                color = if (answered || selected >= 0) Ink else Muted, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ResultScreen(score: Int, total: Int, onHome: () -> Unit, onAgain: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("🏆", fontSize = 64.sp)
        Spacer(Modifier.height(18.dp))
        Text("أحسنت! انتهى التحدي", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text("$score / $total", color = Gold, fontSize = 48.sp, fontWeight = FontWeight.Black)
        Text("إجابات صحيحة", color = Muted)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onAgain, modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(14.dp)) {
            Text("العب مرة أخرى", color = Ink, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth().height(52.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Gold), shape = RoundedCornerShape(14.dp)) {
            Text("العودة للرئيسية", color = Gold)
        }
    }
}
